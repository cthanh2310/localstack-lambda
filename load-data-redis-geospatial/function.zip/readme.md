1. awslocal lambda list-functions
2. awslocal lambda delete-function --function-name abc123
3. awslocal lambda create-function --function-name lambda-test --runtime nodejs18.x --zip-file fileb://output.zip --handler index.handler --role arn:aws:iam::000000000000:role/lambda-role
4. awslocal lambda invoke --function-name lambda-test --payload '"{\"longitude\": \"69\", \"latitude\": \"69\", \"id\": \"id_123\"}"' output.txt

Note:
1. zip -r function.zip .
